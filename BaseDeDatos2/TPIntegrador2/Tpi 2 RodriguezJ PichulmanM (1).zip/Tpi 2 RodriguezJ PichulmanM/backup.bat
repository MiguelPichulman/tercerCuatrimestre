@echo off
set FECHA=%date:/=-%
set CARPETA_DESTINO=resguardos_tpi\%FECHA%

mkdir "%CARPETA_DESTINO%"

mongodump --uri="mongodb+srv://joacol23:utnjoaco123@tpidb.2yeanuh.mongodb.net/LoginTPI" --out="%CARPETA_DESTINO%"

exit