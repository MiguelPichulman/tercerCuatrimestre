const { MongoClient } = require('mongodb');

const uri = "mongodb+srv://profes4:utncom4@tpidb.2yeanuh.mongodb.net/";
const client = new MongoClient(uri);

// 1. CREATE 
async function crearUsuario(coleccion) {
    const nuevoUsuario = {
        email: "nuevo.alumno@ejemplo.com",
        perfil: {
            nombre: "Joaquin",
            apellido: "Rodriguez",
            telefono: "+543511234567"
        },
        fecha_registro: new Date(),
        activo: true,
        fecha_baja: null
    };
    const resultado = await coleccion.insertOne(nuevoUsuario);
    console.log("CREATE: Nuevo usuario registrado con ID:", resultado.insertedId);
    return resultado.insertedId; 
}

// 2. UPDATE 
async function actualizarUsuario(coleccion, idUsuario) {
    const resultado = await coleccion.updateOne(
        { _id: idUsuario },
        { $set: { "perfil.telefono": "+543511234567" } }
    );
    console.log("UPDATE: Campos actualizados. Documentos modificados:", resultado.modifiedCount);
}

// 3. DELETE 
async function eliminarUsuario(coleccion, idUsuario) {
    const resultado = await coleccion.updateOne(
        { _id: idUsuario },
        { $set: { activo: false, fecha_baja: new Date() } }
    );
    console.log("DELETE: Baja aplicada. Documentos modificados:", resultado.modifiedCount);
}

// 4. READ 
async function leerUsuariosActivos(coleccion) {
    const usuariosActivos = await coleccion.find({ activo: true }).toArray();
    console.log("READ: Listando usuarios activos en el sistema:");
    console.log(usuariosActivos);
}

async function main() {
    try {
        await client.connect();
        const database = client.db("LoginTPI");
        const coleccionUsuario = database.collection("usuario");

        console.log("--- INICIANDO FLUJO CRUD ---");

        const idGenerado = await crearUsuario(coleccionUsuario);
        await actualizarUsuario(coleccionUsuario, idGenerado);
        await eliminarUsuario(coleccionUsuario, idGenerado);
        await leerUsuariosActivos(coleccionUsuario);

        console.log("--- FLUJO TERMINADO ---");

    } finally {
        await client.close();
    }
}

main();