# TPI Integrador - Base de Datos II (Parte 2)

**Alumnos:** Pichulman Miguel - Rodriguez Joaquin
**Comision:** 4

---

## 1. Conexion a MongoDB Atlas

En `app.js` se establece la conexion con el cluster de MongoDB Atlas y se obtiene la coleccion `usuario`.

```javascript
const { MongoClient } = require('mongodb');

const uri = "mongodb+srv://profes4:utncom4@tpidb.2yeanuh.mongodb.net/";
const client = new MongoClient(uri);

await client.connect();

const database = client.db("LoginTPI");
const coleccionUsuario = database.collection("usuario");
```

---

## 2. Operaciones CRUD

### CREATE

```javascript
async function crearUsuario(coleccion) {
    const nuevoUsuario = {
        email: "nuevo.alumno@ejemplo.com",
        perfil: {
            nombre: "Joaquin",
            apellido: "Rodriguez",
            telefono: "+543511234567"
        },
        fecha_registro: new Date(),
        activo: true,
        fecha_baja: null
    };

    await coleccion.insertOne(nuevoUsuario);
}
```

### READ

```javascript
async function leerUsuariosActivos(coleccion) {
    return await coleccion.find({ activo: true }).toArray();
}
```

### UPDATE

```javascript
async function actualizarUsuario(coleccion, idUsuario) {
    await coleccion.updateOne(
        { _id: idUsuario },
        { $set: { "perfil.telefono": "+543519999999" } }
    );
}
```

### DELETE (Baja logica)

```javascript
async function eliminarUsuario(coleccion, idUsuario) {
    await coleccion.updateOne(
        { _id: idUsuario },
        { $set: { activo: false, fecha_baja: new Date() } }
    );
}
```

---

## 3. Script de Backup

### `backup.bat`

```bat
@echo off
set FECHA=%date:/=-%
set CARPETA_DESTINO=resguardos_tpi\%FECHA%

mkdir "%CARPETA_DESTINO%"

mongodump --uri="mongodb+srv://joacol23:utnjoaco123@tpidb.2yeanuh.mongodb.net/LoginTPI" --out="%CARPETA_DESTINO%"

exit
```

### RPO y RTO

* **RPO:** 24 horas (backup diario).
* **RTO:** Entre 15 y 30 minutos.

---

## 4. Conclusion

Este TPI permitio implementar las operaciones CRUD sobre MongoDB Atlas, aplicar una estrategia de baja logica para conservar la informacion y automatizar el respaldo de la base de datos mediante `mongodump`, integrando conceptos de desarrollo y administracion de bases de datos NoSQL.
