/**
 * SEMANA 1: FUNDAMENTOS DEL LENGUAJE (LÓGICA PURA)
 */

// --- 1. VARIABLES Y SCOPE ---
const docente = "Luciano"; // Constante: no se puede reasignar.
let materia = "Prog 3"; // Variable: se puede reasignar.

if (true) {
  let bloque = "Solo existo aquí dentro";
  var global = "Soy accesible fuera (mala práctica)";
  console.log("Dentro del bloque:", bloque);
}
// console.log(bloque); // ERROR: bloque is not defined (Scope de bloque)
console.log("Fuera del bloque con var:", global);

// --- 2. ARRAYS (Listas) ---
const alumnos = ["Matias", "Ana", "Raul"];
alumnos.push("Cande"); // Los arrays const son mutables en su contenido

// --- 3. BUCLES (Iteraciones) ---
console.log("--- Recorrido de Array ---");
// Bucle clásico
for (let i = 0; i < alumnos.length; i++) {
  console.log("Índice " + i + ": " + alumnos[i]);
}

// Bucle moderno (for...of) - Muy útil para Prog 3
for (const alumno of alumnos) {
  console.log("Nombre:", alumno);
}

// --- 4. CONDICIONALES ---
let nota = 8;
if (nota >= 7) {
  console.log("Promocionado");
} else if (nota >= 4) {
  console.log("Regular");
} else {
  console.log("Libre");
}

// --- 5. FUNCIONES ---

// A. Función Declarada (Soportan Hoisting)
function sumar(a, b) {
  return a + b;
}

// B. Función Flecha / Arrow Function (Sintaxis moderna)
// Muy usadas para callbacks y métodos de array
const restar = (a, b) => a - b;

// C. Función Flecha de una sola línea (Retorno implícito)
const multiplicar = (a, b) => a * b;

console.log("Resultados:", sumar(10, 5), restar(10, 5), multiplicar(10, 5));

// --- 6. EJERCICIO INTEGRADOR ---
// Crear un array de números y filtrar solo los pares
const numeros = [1, 2, 3, 4, 5, 6];
const pares = [];

for (const num of numeros) {
  if (num % 2 === 0) {
    pares.push(num);
  }
}
console.log("Números pares encontrados:", pares);
