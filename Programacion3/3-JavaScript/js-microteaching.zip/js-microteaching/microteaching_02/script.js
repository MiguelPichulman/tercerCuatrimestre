/**
 * CLASE 2: TODO LIST (DOM + LOCAL STORAGE)
 * Enfoque: Funciones flecha y métodos modernos.
 */

// 1. Estado de la aplicación
let tareas = JSON.parse(localStorage.getItem("tareas_lista")) || [];

// 2. Elementos del DOM
const input = document.querySelector("#todoInput");
const btnAgregar = document.querySelector("#addBtn");
const listaContenedor = document.querySelector("#todoList");

// 3. Lógica de Persistencia
const actualizarStorage = () => {
  localStorage.setItem("tareas_lista", JSON.stringify(tareas));
  render();
};

// 4. Función de Renderizado (Punto neurálgico)
const render = () => {
  listaContenedor.innerHTML = "";

  tareas.forEach((tarea, index) => {
    // Creamos el elemento li
    const li = document.createElement("li");

    // Estructura interna con Template Strings
    li.innerHTML = `
            <span class="${tarea.completada ? "completed" : ""}">${tarea.texto}</span>
            <div>
                <button class="btn-check">✔</button>
                <button class="btn-delete">✖</button>
            </div>
        `;

    // Seleccionamos los botones RECIÉN creados dentro de este li
    const btnCheck = li.querySelector(".btn-check");
    const btnDelete = li.querySelector(".btn-delete");

    // Evento Completar
    btnCheck.addEventListener("click", () => {
      tareas[index].completada = !tareas[index].completada;
      actualizarStorage();
    });

    // Evento Eliminar
    btnDelete.addEventListener("click", () => {
      tareas.splice(index, 1);
      actualizarStorage();
    });

    listaContenedor.appendChild(li);
  });
};

// 5. Agregar Tarea
const agregarTarea = () => {
  const texto = input.value.trim();
  if (texto) {
    tareas.push({ texto, completada: false });
    input.value = "";
    actualizarStorage();
  }
};

// Eventos Globales
btnAgregar.addEventListener("click", agregarTarea);

// Soporte para tecla Enter
input.addEventListener("keypress", (e) => {
  if (e.key === "Enter") agregarTarea();
});

// Inicialización
render();
